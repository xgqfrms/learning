import numpy as np
x = np.random.random(5)
print x
print x + 1   # add 1 to each element of x

