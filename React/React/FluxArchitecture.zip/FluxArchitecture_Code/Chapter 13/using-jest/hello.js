'use strict';

// Builds and returns a string based
// on the "name" argument.
export default function sayHello(name = 'World') {
  return `Hello ${name}!`;
}
