'use strict';

import sayHello from './hello';
sayHello();
