'use strict';

// We're exporting the global "fetch()" function
// so that Jest has an opportunity to mock it.
export default fetch;
