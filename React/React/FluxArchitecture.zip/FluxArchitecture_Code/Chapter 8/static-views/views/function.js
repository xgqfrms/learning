'use strict';

import React from 'react';

// Redends the view content using a functional
// React component.
export default ({ content }) => (
  <strong>{content}</strong>
);
