'use strict';

import settingsView from './views/settings';

export { settingsView as settings };
