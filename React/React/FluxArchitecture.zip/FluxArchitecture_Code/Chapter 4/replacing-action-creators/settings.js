'use strict';

// Controls the implementation that's exported
// from each action creator module.
export const MOCK = true;
