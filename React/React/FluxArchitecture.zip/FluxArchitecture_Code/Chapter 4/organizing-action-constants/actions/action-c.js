'use strict';

export const ACTION_C = 'ACTION_C';
