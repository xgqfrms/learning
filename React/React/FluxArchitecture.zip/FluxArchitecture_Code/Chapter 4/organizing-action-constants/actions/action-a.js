'use strict';

export const ACTION_A = 'ACTION_A';
