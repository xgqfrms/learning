'use strict';

export const ACTION_B = 'ACTION_B';
