'use strict';

// Get things going by importing the view.
import myView from './views/myview';
