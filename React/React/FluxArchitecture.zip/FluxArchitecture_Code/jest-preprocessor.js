module.exports = require('babel-jest');
