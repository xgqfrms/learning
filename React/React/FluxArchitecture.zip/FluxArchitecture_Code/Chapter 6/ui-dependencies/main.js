'use strict';

// Our views...
import checkboxes from './views/checkboxes';
import labels from './views/labels';

// Perform defualt rendering, using the
// initial store state.
checkboxes.render();
labels.render();
