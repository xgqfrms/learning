export const MAIN_LINKS = [
  { title: 'Users', action: 'LOAD_USERS' },
  { title: 'Groups', action: 'LOAD_GROUPS' }
];
