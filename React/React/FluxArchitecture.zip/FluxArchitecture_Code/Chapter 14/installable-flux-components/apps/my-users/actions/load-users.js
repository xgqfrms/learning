'use strict';

export const LOAD_USERS = 'LOAD_USERS';
