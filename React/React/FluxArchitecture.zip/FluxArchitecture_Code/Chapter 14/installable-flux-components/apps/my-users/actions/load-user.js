'use strict';

export const LOAD_USER = 'LOAD_USER';
