'use strict';

export const LOAD_GROUP = 'LOAD_GROUP';
