'use strict';

export const LOAD_GROUPS = 'LOAD_GROUPS';
