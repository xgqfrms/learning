# ReactJS Blueprints - Chapter 1

This folder contains code for chapter 1 and the scaffold we'll be using for all the other chapters

##### scaffold.zip

unzip and install with ```npm install```

#### npm run bundle

This will create a static bundle in the public folder. This folder is now ready to be published.
