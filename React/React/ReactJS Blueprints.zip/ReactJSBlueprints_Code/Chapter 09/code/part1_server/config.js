'use strict';
const config = {
  home: __dirname
};
module.exports = config;
