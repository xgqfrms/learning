//@flow
const s = (
  keys: Object
): bool => {
  return 65 in keys;
}
module.exports = s;
