//@flow
const right = (
  keys: Object
): bool => {
  return 39 in keys;
}
module.exports = right;
