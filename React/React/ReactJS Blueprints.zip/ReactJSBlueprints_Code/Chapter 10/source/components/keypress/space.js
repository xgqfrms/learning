//@flow
const w = (
  keys: Object
): bool => {
  return 32 in keys;
}
module.exports = w;
