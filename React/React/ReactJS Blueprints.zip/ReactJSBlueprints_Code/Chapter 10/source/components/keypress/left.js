//@flow
const left = (
  keys: Object
): bool => {
  return 37 in keys;
}
module.exports = left;
