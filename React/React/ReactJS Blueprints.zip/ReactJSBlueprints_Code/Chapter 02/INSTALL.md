# How to run the app

1. Install the app by executing 

    npm install

2. Run the development server by executing 

    node server.js

This will start the server and automatically open a browser window for you, usually with the address http://localhost:3000
