'use strict';
import Request from './request.js';

class SearchService extends Request {

}

module.exports = SearchService;
