import { Dispatcher } from "flux";

const pageDispatcher = new Dispatcher();

export default pageDispatcher;
