import PageAdmin from "./src/page-admin";
import PageDispatcher from "./src/page-dispatcher";
import PageStore from "./src/page-store";
import React from "react";
import ReactDOMServer from "react-dom/server";

PageDispatcher.dispatch({
    "action": "ADD_PAGE"
});

PageDispatcher.dispatch({
    "action": "ADD_PAGE"
});

PageDispatcher.dispatch({
    "action": "ADD_PAGE"
});

console.log(
    ReactDOMServer.renderToString(
        <PageAdmin />
    )
);
