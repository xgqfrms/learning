var React = require("react");
var ReactDOMServer = require("react-dom/server");

var script = {
    "__html": `
        var socket = io();

        socket.on("message", function (message) {
            console.log(message);
        });

        socket.emit("message", "hello world");
    `
};

module.exports = ReactDOMServer.renderToString(
    <div>
        <script src="/socket.io/socket.io.js"></script>
        <script dangerouslySetInnerHTML={script}></script>
    </div>
);
