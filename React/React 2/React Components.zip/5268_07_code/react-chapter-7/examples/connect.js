var socket = io();

socket.on("message", function (message) {
    console.log(message);
});

socket.emit("hello world");
