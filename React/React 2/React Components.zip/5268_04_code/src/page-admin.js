import React from "react";
import ReactDOM from "react-dom";
import Component from "component";
import Page from "page";
import Backend from "backend";

class PageAdmin extends Component {
    constructor(props) {
        super(props);

        this.bind(
            "onInsert",
            "onUpdate",
            "onDelete"
        );

        this.state = {
            "pages": this.props.backend.getAll()
        };

        this.props.backend.on("update",
            (pages) => this.setState({pages})
        );
    }

    componentWillMount() {
        this.setState({
            "pages": this.props.backend.getAll()
        });
    }

    render() {
        var itemStyle = this.props.itemStyle || {
            "minHeight": "40px",
            "lineHeight": "40px"
        };

        return <div>
            <div>
                <button onClick={this.onInsert}>
                    create new page
                </button>
            </div>
            <ol>
            <React.addons.CSSTransitionGroup
                transitionName="page"
                transitionEnterTimeout={150}
                transitionLeaveTimeout={150}>
                    {this.state.pages.map((page) => {
                        return <li key={page.id} style={itemStyle}>
                            <Page
                                {...page}
                                onUpdate={this.onUpdate}
                                onDelete={this.onDelete}
                                />
                        </li>;
                    })}
                </React.addons.CSSTransitionGroup>
            </ol>
        </div>;
    }

    onInsert() {
        this.props.backend.insert();
    }

    onUpdate(...params) {
        this.props.backend.update(...params);
    }

    onDelete(...params) {
        this.props.backend.delete(...params);
    }
}

PageAdmin.propTypes = {
    "backend": function(props, propName, componentName) {
        if (props.backend instanceof Backend) {
            return;
        }

        return new Error(
            "Required prop `backend` is not a `Backend`."
        );
    }
};

export default PageAdmin;
