import React from "react";
import Component from "src/component";
import Page from "src/page";
import Backend from "src/backend";

class PageAdmin extends Component {
    constructor(props) {
        super(props);

        this.bind(
            "onInsert",
            "onUpdate",
            "onDelete"
        );

        this.state = {
            "pages": this.props.backend.getAll()
        };

        this.props.backend.on("update",
            (pages) => this.setState({pages})
        );
    }

    onInsert() {
        this.props.backend.insert();
    }

    onUpdate(...props) {
        this.props.backend.update(...props);
    }

    onDelete(...props) {
        this.props.backend.delete(...props);
    }

    componentWillMount() {
        this.setState({
            "pages": this.props.backend.getAll()
        });
    }

    render() {
        var contentClassNames = [
            "mdl-layout__content",
            "mdl-color--grey-100"
        ].join(" ");

        var addButtonClassNames = [
            "mdl-button",
            "mdl-js-button",
            "mdl-button--fab",
            "mdl-js-ripple-effect",
            "mdl-button--colored"
        ].join(" ");

        return <div className={contentClassNames}>
            <button onClick={this.onInsert}
                className={addButtonClassNames}>
                <i className="material-icons">add</i>
            </button>
            {this.state.pages.map((page) => {
                return (
                    <Page {...page}
                        key={page.id}
                        onUpdate={this.onUpdate}
                        onDelete={this.onDelete} />
                );
            })}
        </div>;
    }
}

PageAdmin.propTypes = {
    "backend": function(props, propName, componentName) {
        if (props.backend instanceof Backend) {
            return;
        }

        return new Error(
            "Required prop `backend` is not a `Backend`."
        );
    }
};

export default PageAdmin;
