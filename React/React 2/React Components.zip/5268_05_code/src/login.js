import React from "react";
import ReactDOM from "react-dom";

export default (props) => {
    var contentClassNames = [
        "mdl-layout__content",
        "mdl-color--grey-100"
    ].join(" ");

    var gridClassNames = [
        "mdl-grid",
        "demo-content"
    ].join(" ");

    var fieldClassNames = [
        "mdl-textfield",
        "mdl-js-textfield"
    ].join(" ");

    return (
        <div className={contentClassNames}>
            <form className={gridClassNames}>
                <div className={fieldClassNames}>
                    <input className="mdl-textfield__input"
                        type="text" />
                    <label className="mdl-textfield__label"
                        htmlFor="sample1">
                        Email...
                    </label>
                </div>
                <div className={fieldClassNames}>
                    <input className="mdl-textfield__input"
                        type="text" />
                    <label className="mdl-textfield__label"
                        htmlFor="sample1">
                        Password...
                    </label>
                </div>
            </form>
        </div>
    );
};
