import React from "react";
import Component from "src/component";

class PageView extends Component {
    constructor(props) {
        super(props);

        this.bind(
            "onDelete"
        );
    }

    isChanged(next, previous) {
        return JSON.stringify(next) !== JSON.stringify(previous)
    }

    shouldComponentUpdate(props, state) {
        return this.isChanged(props, this.props);
    }

    render() {
        var cardClassNames = [
            "demo-card-wide",
            "mdl-card",
            "mdl-shadow--2dp"
        ].join(" ");

        var buttonClassNames = [
            "mdl-button",
            "mdl-button--icon",
            "mdl-js-button",
            "mdl-js-ripple-effect"
        ].join(" ");

        return (
            <div className={cardClassNames}>
                <div className="mdl-card__title">
                    <h2 className="mdl-card__title-text">
                        {this.props.title}
                    </h2>
                </div>
                <div className="mdl-card__supporting-text">
                    {this.props.body}
                </div>
                <div className="mdl-card__menu">
                    <button className={buttonClassNames}
                        onClick={this.props.onEdit}>
                    <i className="material-icons">edit</i>
                    </button>
                    <button className={buttonClassNames}
                        onClick={this.props.onDelete}>
                        <i className="material-icons">delete</i>
                    </button>
                </div>
            </div>
        );
    }

    onDelete() {
        this.props.onDelete(
            this.props.id
        );
    }
}

PageView.propTypes = {
    "title": React.PropTypes.string.isRequired,
    "onEdit": React.PropTypes.func.isRequired,
    "onDelete": React.PropTypes.func.isRequired
};

export default PageView;
