import React from "react";
import Component from "src/component";
import PageEditor from "src/page-editor";
import PageView from "src/page-view";

class Page extends Component {
    constructor(props) {
        super(props);

        this.state = {
            "isEditing": false
        };

        this.bind(
            "onEdit",
            "onDelete",
            "onCancel",
            "onSave"
        );
    }

    render() {
        if (this.state.isEditing) {
            return (
                <PageEditor
                    {...this.props}
                    onCancel={this.onCancel}
                    onSave={this.onSave} />
            );
        }

        return (
            <PageView
                {...this.props}
                onEdit={this.onEdit.bind(this)}
                onDelete={this.onDelete.bind(this)} />
        );
    }

    onEdit() {
        this.setState({
            "isEditing": true,
            "title": this.props.title
        });
    }

    onDelete() {
        this.props.onDelete(this.props.id);
    }

    onCancel() {
        this.props.onUpdate(
            this.props.id,
            "title",
            this.state.title
        );

        this.setState({
            "isEditing": false
        });
    }

    onSave() {
        this.setState({
            "isEditing": false
        });
    }
}

Page.propTypes = {
    "id": React.PropTypes.number.isRequired,
    "onDelete": React.PropTypes.func.isRequired
};

export default Page;
