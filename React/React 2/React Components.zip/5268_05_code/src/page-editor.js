import React from "react";
import Component from "src/component";

class PageEditor extends Component {
    constructor(props) {
        super(props);

        this.state = {
            "changed": false
        };

        this.bind(
            "onUpdate",
            "onSave",
            "onCancel"
        );
    }

    isChanged(next, previous) {
        return JSON.stringify(next) !== JSON.stringify(previous)
    }

    componentWillReceiveProps(props) {
        this.setState({
            "changed": this.isChanged(props, this.props)
        });
    }

    render() {
        var cancelButtonStyle = null;
        var saveButton = null;

        if (this.state.changed) {
            cancelButtonStyle = {
                "margin": "0 0 0 10px"
            };

            saveButton = (
                <button onClick={this.onSave}>
                    save
                </button>
            );
        }

        return (
            <form>
                <div>
                    <input
                        type="text"
                        onChange={this.onUpdate}
                        name="title"
                        value={this.props.title} />
                </div>
                <div>
                    <input
                        type="text"
                        onChange={this.onUpdate}
                        name="body"
                        value={this.props.body} />
                </div>
                {saveButton}
                <button
                    onClick={this.onCancel}
                    style={cancelButtonStyle}>
                    cancel
                </button>
            </form>
        );
    }

    onUpdate(event) {
        this.props.onUpdate(
            this.props.id,
            event.target.name,
            event.target.value
        );
    }

    onSave(event) {
        event.preventDefault();
        this.props.onSave();
    }

    onCancel(event) {
        event.preventDefault();
        this.props.onCancel();
    }
}

PageEditor.propTypes = {
    "id": React.PropTypes.number.isRequired,
    "title": React.PropTypes.string.isRequired,
    "body": React.PropTypes.string.isRequired,
    "onUpdate": React.PropTypes.func.isRequired,
    "onCancel": React.PropTypes.func.isRequired
};

export default PageEditor;
