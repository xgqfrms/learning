import React from "react";
import ReactDOM from "react-dom";
import Nav from "src/nav";
import Backend from "src/backend";
import PageAdmin from "src/page-admin";

var backend = new Backend();

var layoutClassNames = [
    "demo-layout",
    "mdl-layout",
    "mdl-js-layout",
    "mdl-layout--fixed-drawer"
].join(" ");

ReactDOM.render(
    <div className={layoutClassNames}>
        <Nav />
        <PageAdmin backend={backend} />
    </div>,
    document.querySelector(".react")
);
