import React from "react";
import ReactDOM from "react-dom";
import Nav from "src/nav";
import Login from "src/login";

var layoutClassNames = [
    "demo-layout",
    "mdl-layout",
    "mdl-js-layout",
    "mdl-layout--fixed-drawer"
].join(" ");

ReactDOM.render(
    <div className={layoutClassNames}>
        <Nav />
        <Login />
    </div>,
    document.querySelector(".react")
);
