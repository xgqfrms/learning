import { Ioc } from "adonis-fold";

Ioc.autoload("App", __dirname + "/src");

import React from "react";
import ReactDOMServer from "react-dom/server";

const PagesComponent = Ioc.use("App/PagesComponent");

Ioc.bind("App/PagesComponent{}", function() {
    return (
        <PagesComponent />
    );
});

// ...then, when we want to decorate the component

class PagesComponentChrome extends React.Component {
    render() {
        return (
            <div className="chrome">
                {this.props.children}
            </div>
        )
    }
}

Ioc.bind("App/PagesComponent{}", function() {
    return (
        <PagesComponentChrome>
            <PagesComponent />
        </PagesComponentChrome>
    );
});

// ...some time later

const NewPagesComponent = Ioc.use("App/PagesComponent{}");

console.log(
    ReactDOMServer.renderToString(
        <div>{NewPagesComponent}</div>
    )
);
