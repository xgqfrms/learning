import React from "react";

class DummyPageEditorComponent extends React.Component {
    render() {
        return (
            <div>page editor</div>
        );
    }
}

module.exports = DummyPageEditorComponent;
