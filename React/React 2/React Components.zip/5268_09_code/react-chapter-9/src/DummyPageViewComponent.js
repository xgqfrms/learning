import React from "react";

class DummyPageViewComponent extends React.Component {
    render() {
        return (
            <div>page details</div>
        );
    }
}

module.exports = DummyPageViewComponent;
