class AuthenticatorLogger {
    static get inject() {
        return [
            "App/Authenticator",
        ];
    }

    constructor(authenticator) {
        this.authenticator = authenticator;
    }

    authenticate(email, password) {
        this.log("authentication attempted");

        return this.authenticator.authenticate(email, password);
    }

    log(message) {
        // ...store the log message
    }
}

module.exports = AuthenticatorLogger;
