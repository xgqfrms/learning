class Authenticator {
    static get inject() {
        return [
            "App/Repository",
            "App/Crypto",
        ];
    }

    constructor(repository, crypto) {
        this.repository = repository;
        this.crypto = crypto;
    }

    authenticate(email, password) {
        // ...authenticate the user details
    }
}

module.exports = Authenticator;
