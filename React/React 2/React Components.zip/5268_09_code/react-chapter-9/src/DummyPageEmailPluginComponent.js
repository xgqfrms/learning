import React from "react";

class DummyPageEmailPluginComponent extends React.Component {
    render() {
        return (
            <div>email page</div>
        );
    }
}

module.exports = DummyPageEmailPluginComponent;
