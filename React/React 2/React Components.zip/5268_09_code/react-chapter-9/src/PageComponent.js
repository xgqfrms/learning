import React from "react";

class PageComponent extends React.Component {
    constructor(props) {
        super(props);
        this.state = props.store.getState();
    }
    componentDidMount() {
        this.remove = this.props.store.register(
            this.onChange
        );
    }
    componentWillUnmount() {
        this.remove();
    }
    onChange() {
        this.setState(this.props.store.getState());
    }
    render() {
        const components = use("App/PageComponentChildren");

        return (
            <div>
                {components.map((Component, i) => {
                    return <Component key={i} />;
                })}
            </div>
        );
    }
}

module.exports = PageComponent;
