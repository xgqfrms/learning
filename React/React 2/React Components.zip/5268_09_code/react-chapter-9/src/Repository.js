class Repository {
    // ...probably fetches users from a data source
}

module.exports = Repository;
