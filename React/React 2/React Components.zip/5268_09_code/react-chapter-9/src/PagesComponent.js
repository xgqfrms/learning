import React from "react";

class PagesComponent extends React.Component {
    constructor(props, context) {
        super();

        // ...get context.store state
    }
    componentDidMount() {
        // ...add context.store change listener
    }
    componentWillUnmount() {
        // ...remove context.store change listener
    }
    render() {
        // ...return a list of pages

        return <div>pages</div>;
    }
}

module.exports = PagesComponent;
