import React from "react";

class PageEditorComponent extends React.Component {
    onSave(e, refs) {
        if (this.props.onBeforeSave) {
            if (!this.props.onBeforeSave(e, refs)) {
                return;
            }
        }

        // ...save the data

        if (this.props.onAfterSave) {
            this.props.onAfterSave(e, refs);
        }
    }
    onCancel(e, refs) {
        // ...cancel the edit
    }
    render() {
        let refs = {};

        return (
            <div>
                <input type="text"
                    ref={ref => refs.title = ref} />
                <input type="text"
                    ref={ref => refs.body = ref} />
                <button onClick={e => this.onSave(e, refs)}>
                    save
                </button>
                <button onClick={e => this.onCancel(e, refs)}>
                    cancel
                </button>
            </div>
        );
    }
}

PageEditorComponent.propTypes = {
    "onSave": React.PropTypes.func.isRequired,
    "onCancel": React.PropTypes.func.isRequired,
    "onBeforeSave": React.PropTypes.func,
    "onAfterSave": React.PropTypes.func
};

module.exports = PageEditorComponent;
