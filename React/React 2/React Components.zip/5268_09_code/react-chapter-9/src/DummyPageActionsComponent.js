import React from "react";

class DummyPageActionsComponent extends React.Component {
    render() {
        return (
            <div>
                <button>edit</button>
                <button>delete</button>
            </div>
        );
    }
}

module.exports = DummyPageActionsComponent;
