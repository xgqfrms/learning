class Crypto {
    // ...probably performs cryptographic comparisons
}

module.exports = Crypto;
