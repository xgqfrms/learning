require("babel-register");
// require("./simple-binding");
// require("./autoloading-and-decorating");
// require("./replacing-components");
require("./redux-plugins");
