import React from "react";
import ReactDOMServer from "react-dom/server";
import { combineReducers, createStore } from "redux";
import { Ioc } from "adonis-fold";

Ioc.autoload("App", __dirname + "/src");

Ioc.bind("App/Reducers", function() {
    return [
        (state = {}, action) => {
            let pages = state.pages || [];

            if (action.type == "UPDATE_TITLE") {
                pages = pages.map((page) => {
                    if (page.id = payload.id) {
                        page.title = payload.title;
                    }

                    return page;
                });
            }

            return {
                pages
            };
        }
    ];
});

Ioc.bind("App/Store", function() {
    const reducers = combineReducers(
        Ioc.use("App/Reducers")
    );

    return createStore(reducers);
});

Ioc.bind("App/PageComponentChildren", function() {
    return [
        use("App/DummyPageViewComponent"),
        use("App/DummyPageEditorComponent"),
        use("App/DummyPageActionsComponent"),
    ];
});

const Store = Ioc.use("App/Store");
const PageComponent = Ioc.use("App/PageComponent");

let rendered = ReactDOMServer.renderToString(
    <PageComponent store={Store} />
);

// ...and we can add plugins

const PageComponentChildren = use("App/PageComponentChildren");

Ioc.bind("App/PageComponentChildren", function() {
    return [
        ...PageComponentChildren,
        use("App/DummyPageEmailPluginComponent"),
    ];
});

let extended = ReactDOMServer.renderToString(
    <PageComponent store={Store} />
);

console.log(extended);
