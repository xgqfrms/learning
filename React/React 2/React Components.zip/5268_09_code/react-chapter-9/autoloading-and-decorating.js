import { Ioc } from "adonis-fold";

Ioc.autoload("App", __dirname + "/src");

const Authenticator = Ioc.use("App/Authenticator");
const AuthenticatorLogger = Ioc.use("App/AuthenticatorLogger");

Ioc.bind("App/Authenticator", function(authenticator) {
    return new AuthenticatorLogger(Ioc.make(Authenticator));
});

let authenticator = Ioc.make("App/Authenticator");

console.log(authenticator);
