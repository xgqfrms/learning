import { Ioc } from "adonis-fold";

Ioc.bind("App/Authenticator", function() {
    // ...return a new Authenticator
    return "a new authenticator";
});

let object = Ioc.use("App/Authenticator");

console.log(object);
