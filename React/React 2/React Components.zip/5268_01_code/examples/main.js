import React from "react";
import ReactDOM from "react-dom";
import Page from "page";

ReactDOM.render(
    <Page content="Welcome to my site!" />,
    document.querySelector(".react")
);
