import React from "react";
import ReactDOM from "react-dom";
import Component from "component";

class PageView extends Component {
    constructor(props) {
        super(props);

        this.bind(
            "handlePageDelete"
        );
    }

    isChanged(next, previous) {
        return JSON.stringify(next) !== JSON.stringify(previous)
    }

    shouldComponentUpdate(props, state) {
        return this.isChanged(props, this.props);
    }

    render() {
        return <div>
            {this.props.title}
            <button
                onClick={this.props.onPageEdit}
                >edit</button>
            <button
                onClick={this.handlePageDelete}
                >delete</button>
        </div>;
    }

    handlePageDelete() {
        this.props.onPageDelete(
            this.props.id
        );
    }
}

PageView.propTypes = {
    "title": React.PropTypes.string.isRequired,
    "onPageEdit": React.PropTypes.func.isRequired,
    "onPageDelete": React.PropTypes.func.isRequired
};

export default PageView;
