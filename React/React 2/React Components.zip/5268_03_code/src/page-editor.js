import React from "react";
import ReactDOM from "react-dom";
import Component from "component";

class PageEditor extends Component {
    constructor(props) {
        super(props);

        this.state = {
            "changed": false
        };

        this.bind(
            "handlePageUpdate"
        );
    }

    isChanged(next, previous) {
        return JSON.stringify(next) !== JSON.stringify(previous)
    }

    componentWillReceiveProps(props) {
        this.setState({
            "changed": this.isChanged(props, this.props)
        });
    }

    render() {
        return <div>
            <input
                type="text"
                name="title"
                value={this.props.title}
                onChange={this.handlePageUpdate}
                />
            <input
                type="text"
                name="body"
                value={this.props.body}
                onChange={this.handlePageUpdate}
                />
            <button
                onClick={this.props.onPageCancel}
                >cancel</button>
        </div>;
    }

    handlePageUpdate(event) {
        this.props.onPageUpdate(
            this.props.id,
            event.target.name,
            event.target.value
        );
    }
}

PageEditor.propTypes = {
    "id": React.PropTypes.number.isRequired,
    "title": React.PropTypes.string.isRequired,
    "body": React.PropTypes.string.isRequired,
    "onPageUpdate": React.PropTypes.func.isRequired,
    "onPageCancel": React.PropTypes.func.isRequired
};

export default PageEditor;
