import React from "react";
import ReactDOM from "react-dom";
import Component from "component";
import Page from "page";
import Backend from "backend";

class PageAdmin extends Component {
    constructor(props) {
        super(props);

        this.bind(
            "handlePageUpdate",
            "handlePageDelete"
        );

        this.state = {
            "pages": this.props.backend.all()
        };

        this.props.backend.on("update",
            (pages) => this.setState({pages})
        );
    }

    handlePageUpdate(id, field, value) {
        this.props.backend.update(id, field, value);
    }

    handlePageDelete(id) {
        this.props.backend.delete(id);
    }

    componentWillMount() {
        this.setState({
            "pages": this.props.backend.all()
        });
    }

    render() {
        return <ol>
            {this.state.pages.map((page) => {
                return <li key={page.id}>
                    <Page
                        {...page}
                        onPageUpdate={this.handlePageUpdate}
                        onPageDelete={this.handlePageDelete}
                        />
                </li>;
            })}
        </ol>;
    }

    handlePageUpdate(...params) {
        this.props.backend.update(...params);

        this.setState({
            "pages": this.props.backend.all()
        });
    }

    handlePageDelete(...params) {
        this.props.backend.delete(...params);

        this.setState({
            "pages": this.props.backend.all()
        });
    }
}

PageAdmin.propTypes = {
    "backend": function(props, propName, componentName) {
        if (props.backend instanceof Backend) {
            return;
        }

        return new Error(
            "Required prop `backend` is not a `Backend`."
        );
    }
};

export default PageAdmin;
