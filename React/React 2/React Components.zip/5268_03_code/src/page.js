import React from "react";
import ReactDOM from "react-dom";
import PageEditor from "page-editor";
import PageView from "page-view";

class Page extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            "isEditing": false
        };
    }

    render() {
        if (this.state.isEditing) {
            return <PageEditor
                {...this.props}
                onPageCancel={this.handlePageCancel.bind(this)}
                />;
        }

        return <PageView
            {...this.props}
            onPageEdit={this.handlePageEdit.bind(this)}
            />;
    }

    handlePageEdit() {
        this.setState({
            "isEditing": true
        });
    }

    handlePageCancel() {
        this.setState({
            "isEditing": false
        });
    }
}

Page.propTypes = {
    "id": React.PropTypes.number.isRequired,
    "onPageDelete": React.PropTypes.func.isRequired
};

export default Page;
