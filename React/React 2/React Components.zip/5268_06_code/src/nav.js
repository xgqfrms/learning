import React from "react";
import ReactDOM from "react-dom";
import { Link } from "router";

export default (props) => {
    var drawerClassNames = [
        "demo-drawer",
        "mdl-layout__drawer",
        "mdl-color--blue-grey-900",
        "mdl-color-text--blue-grey-50"
    ].join(" ");

    var navClassNames = [
        "demo-navigation",
        "mdl-navigation",
        "mdl-color--blue-grey-800"
    ].join(" ");

    var iconClassNames = [
        "mdl-color-text--blue-grey-400",
        "material-icons"
    ].join(" ");

    var buttonIconClassNames = [
        "mdl-color-text--blue-grey-400",
        "material-icons"
    ].join(" ");

    return <div className={drawerClassNames}>
        <header className="demo-drawer-header">
            <img src="images/user.jpg"
                 className="demo-avatar" />
        </header>
        <nav className={navClassNames}>
            <Link className="mdl-navigation__link" to="login">
                <i className={buttonIconClassNames}
                   role="presentation">
                    lock
                </i>
                Login
            </Link>
            <Link className="mdl-navigation__link" to="page-admin">
                <i className={buttonIconClassNames}
                   role="presentation">
                    pages
                </i>
                Pages
            </Link>
        </nav>
    </div>;
};
