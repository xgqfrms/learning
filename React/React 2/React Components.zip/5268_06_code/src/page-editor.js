import React from "react";
import Component from "src/component";

class PageEditor extends Component {
    constructor(props) {
        super(props);

        this.state = {
            "changed": false
        };

        this.bind(
            "handlePageUpdate"
        );
    }

    isChanged(next, previous) {
        return JSON.stringify(next) !== JSON.stringify(previous)
    }

    componentWillReceiveProps(props) {
        this.setState({
            "changed": this.isChanged(props, this.props)
        });
    }

    render() {
        var cancelButtonStyle = null;
        var saveButton = null;

        if (this.state.changed) {
            cancelButtonStyle = {
               "margin": "0 0 0 10px"
            };

            saveButton = <button
                onClick={this.props.onPageSave}>
                save
            </button>
        }

        return <div>
            <div>
                <input
                    type="text"
                    onChange={this.handlePageUpdate}
                    name="title"
                    value={this.props.title}
                    />
            </div>
            <div>
                <input
                    type="text"
                    onChange={this.handlePageUpdate}
                    name="body"
                    value={this.props.body}
                    />
            </div>
            {saveButton}
            <button
                onClick={this.props.onPageCancel}
                style={cancelButtonStyle}>
                cancel
            </button>
        </div>;
    }

    handlePageUpdate(event) {
        this.props.onPageUpdate(
            this.props.id,
            event.target.name,
            event.target.value
        );
    }
}

PageEditor.propTypes = {
    "id": React.PropTypes.number.isRequired,
    "title": React.PropTypes.string.isRequired,
    "body": React.PropTypes.string.isRequired,
    "onPageUpdate": React.PropTypes.func.isRequired,
    "onPageCancel": React.PropTypes.func.isRequired
};

export default PageEditor;
