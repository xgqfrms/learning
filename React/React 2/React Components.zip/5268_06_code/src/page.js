import React from "react";
import Component from "src/component";
import PageEditor from "src/page-editor";
import PageView from "src/page-view";

class Page extends Component {
    constructor(props) {
        super(props);

        this.state = {
            "isEditing": false
        };

        this.bind(
            "handlePageEdit",
            "handlePageDelete",
            "handlePageCancel",
            "handlePageSave"
        );
    }

    render() {
        if (this.state.isEditing) {
            return <PageEditor
                {...this.props}
                onPageCancel={this.handlePageCancel}
                onPageSave={this.handlePageSave}
                />;
        }

        return <PageView
            {...this.props}
            onPageEdit={this.handlePageEdit.bind(this)}
            onPageDelete={this.handlePageDelete.bind(this)}
            />;
    }

    handlePageEdit() {
        this.setState({
            "isEditing": true,
            "title": this.props.title
        });
    }

    handlePageDelete() {
        this.props.onPageDelete(this.props.id);
    }

    handlePageCancel() {
        this.props.onPageUpdate(
            this.props.id,
            "title",
            this.state.title
        );

        this.setState({
            "isEditing": false
        });
    }

    handlePageSave() {
        this.setState({
            "isEditing": false
        });
    }
}

Page.propTypes = {
    "id": React.PropTypes.number.isRequired,
    "onPageDelete": React.PropTypes.func.isRequired
};

export default Page;
