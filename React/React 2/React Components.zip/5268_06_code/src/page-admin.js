import React from "react";
import Component from "src/component";
import Page from "src/page";
import Backend from "src/backend";

class PageAdmin extends Component {
    constructor(props) {
        super(props);

        this.bind(
            "handlePageInsert",
            "handlePageUpdate",
            "handlePageDelete"
        );

        this.state = {
            "pages": this.props.backend.all()
        };

        this.props.backend.on("update",
            (pages) => this.setState({pages})
        );
    }

    handlePageInsert() {
        this.props.backend.insert();

        this.setState({
            "pages": this.props.backend.all()
        });
    }

    handlePageUpdate(...props) {
        this.props.backend.update(...props);

        this.setState({
            "pages": this.props.backend.all()
        });
    }

    handlePageDelete(...props) {
        this.props.backend.delete(...props);

        this.setState({
            "pages": this.props.backend.all()
        });
    }

    componentWillMount() {
        this.setState({
            "pages": this.props.backend.all()
        });
    }

    render() {
        var contentClassNames = [
            "mdl-layout__content",
            "mdl-color--grey-100"
        ].join(" ");

        var addButtonClassNames = [
            "mdl-button",
            "mdl-js-button",
            "mdl-button--fab",
            "mdl-js-ripple-effect",
            "mdl-button--colored"
        ].join(" ");

        return <div className={contentClassNames}>
            <button onClick={this.handlePageInsert}
                    className={addButtonClassNames}>
                <i className="material-icons">add</i>
            </button>
            {this.state.pages.map((page) => {
                return (
                    <Page {...page}
                          key={page.id}
                          onPageUpdate={this.handlePageUpdate}
                          onPageDelete={this.handlePageDelete} />
                );
            })}
        </div>;
    }
}

PageAdmin.propTypes = {
    "backend": function(props, propName, componentName) {
        if (props.backend instanceof Backend) {
            return;
        }

        return new Error(
            "Required prop `backend` is not a `Backend`."
        );
    }
};

export default PageAdmin;
