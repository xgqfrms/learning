import React from "react";
import Component from "src/component";

class PageView extends Component {
    constructor(props) {
        super(props);

        this.bind(
            "handlePageDelete"
        );
    }

    isChanged(next, previous) {
        return JSON.stringify(next) !== JSON.stringify(previous)
    }

    shouldComponentUpdate(props, state) {
        return this.isChanged(props, this.props);
    }

    render() {
        var cardClassNames = [
            "demo-card-wide",
            "mdl-card",
            "mdl-shadow--2dp"
        ].join(" ");

        var buttonClassNames = [
            "mdl-button",
            "mdl-button--icon",
            "mdl-js-button",
            "mdl-js-ripple-effect"
        ].join(" ");

        return <div className={cardClassNames}>
            <div className="mdl-card__title">
              <h2 className="mdl-card__title-text">
                  {this.props.title}
              </h2>
            </div>
            <div className="mdl-card__supporting-text">
              {this.props.body}
            </div>
            <div className="mdl-card__menu">
              <button className={buttonClassNames}
                      onClick={this.props.onPageEdit}>
                <i className="material-icons">edit</i>
              </button>
              <button className={buttonClassNames}
                      onClick={this.props.onPageDelete}>
                <i className="material-icons">delete</i>
              </button>
            </div>
        </div>;
    }

    handlePageDelete() {
        this.props.onPageDelete(
            this.props.id
        );
    }
}

PageView.propTypes = {
    "title": React.PropTypes.string.isRequired,
    "onPageEdit": React.PropTypes.func.isRequired,
    "onPageDelete": React.PropTypes.func.isRequired
};

export default PageView;
