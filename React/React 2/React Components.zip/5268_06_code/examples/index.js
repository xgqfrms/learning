import React from "react";
import ReactDOM from "react-dom";
import Backend from "src/backend";
import { Router, Link, browserHistory, IndexRoute, Route } from "router";

var Nav = function(props) {
    return (
        <ol className="nav">
            {props.pages.map((page) => {
                return (
                    <li>
                        <Link key={page.id} to={"pages/" + page.id}>
                            {page.title}
                        </Link>
                    </li>
                );
            })}
        </ol>
    );
};

var StaticPage = function(props) {
    var id = props.params.page || 1;
    var backend = props.route.backend;

    var pages = backend.all().filter(
        (page) => {
            return page.id == id;
        }
    );

    if (pages.length < 1) {
        return <div>not found</div>;
    }

    return (
        <div className="page">
            <h1>{pages[0].title}</h1>
            {pages[0].body}
        </div>
    );
};

var App = function(props) {
    return (
        <div className="layout">
            <Nav pages={props.route.backend.all()} />
            {props.children}
        </div>
    );
};

var backend = new Backend();

ReactDOM.render(
    <Router history={browserHistory}>
        <Route path="/" component={App} backend={backend}>
            <IndexRoute component={StaticPage} backend={backend} />
            <Route path="pages/:page" component={StaticPage} backend={backend} />
        </Route>
    </Router>,
    document.querySelector(".react")
);
