import React from "react";
import ReactDOM from "react-dom";
import Component from "component";
import PageEditor from "page-editor";
import PageView from "page-view";

class Page extends Component {
    constructor(props) {
        super(props);

        this.bind(
            "onEdit",
            "onCancel"
        );

        this.state = {
            "isEditing": false
        };
    }

    render() {
        if (this.state.isEditing) {
            return <PageEditor
                {...this.props}
                onCancel={this.onCancel}
                />;
        }

        return <PageView
            {...this.props}
            onEdit={this.onEdit}
            />;
    }

    onEdit() {
        this.setState({
            "isEditing": true
        });
    }

    onCancel() {
        this.setState({
            "isEditing": false
        });
    }
}

export default Page;
