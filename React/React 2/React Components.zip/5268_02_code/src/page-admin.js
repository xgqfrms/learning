import React from "react";
import ReactDOM from "react-dom";
import Component from "component";
import Page from "page";

class PageAdmin extends Component {
    constructor(props) {
        super(props);

        this.state = {
            "pages": []
        };

        this.bind(
            "onUpdate",
            "onDelete"
        );
    }

    componentWillMount() {
        this.setState({
            "pages": this.props.backend.getAll()
        });
    }

    render() {
        return <ol>
            {this.state.pages.map((page) => {
                return <li key={page.id}>
                    <Page
                        {...page}
                        onUpdate={this.onUpdate}
                        onDelete={this.onDelete}
                        />
                </li>;
            })}
        </ol>;
    }

    onUpdate(...params) {
        this.props.backend.update(...params);

        this.setState({
            "pages": this.props.backend.getAll()
        });
    }

    onDelete(...params) {
        this.props.backend.delete(...params);

        this.setState({
            "pages": this.props.backend.getAll()
        });
    }
}

export default PageAdmin;
