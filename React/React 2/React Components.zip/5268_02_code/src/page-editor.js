import React from "react";
import ReactDOM from "react-dom";
import Component from "component";

class PageEditor extends Component {
    constructor(props) {
        super(props);

        this.state = {
            "changed": false
        };

        this.bind(
            "onUpdate",
            "onCancel"
        );
    }

    isChanged(next, previous) {
        return JSON.stringify(next) !== JSON.stringify(previous)
    }

    componentWillReceiveProps(props) {
        this.setState({
            "changed": this.isChanged(props, this.props)
        });
    }

    render() {
        return <form>
            <input
                type="text"
                name="title"
                value={this.props.title}
                onChange={this.onUpdate}
                />
            <textarea
                name="body"
                value={this.props.body}
                onChange={this.onUpdate}>
            </textarea>
            <button
                onClick={this.onCancel}
                >cancel</button>
        </form>;
    }

    onUpdate(event) {
        this.props.onUpdate(
            this.props.id,
            event.target.name,
            event.target.value
        );
    }

    onCancel(event) {
        event.preventDefault();
        this.props.onCancel();
    }
}

export default PageEditor;
