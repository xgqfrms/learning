import React from "react";
import ReactDOM from "react-dom";
import Backend from "backend";
import PageAdmin from "page-admin";

var backend = new Backend();

ReactDOM.render(
    <PageAdmin backend={backend} />,
    document.querySelector(".react")
);
